<?php

/**
 * @defgroup plugins_themes_ahlamzyy AhlamZyy Theme plugin
 */

/**
 * @file plugins/themes/ahlamzyy/index.php
 *
 * @ingroup plugins_themes_ahlamzyy
 * @brief Wrapper untuk AhlamZyy theme plugin.
 */

require_once('AhlamZyyThemePlugin.inc.php');

return new AhlamZyyThemePlugin();
