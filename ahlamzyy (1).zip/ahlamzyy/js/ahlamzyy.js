/**
 * AhlamZyy Theme – Global JS (Premium)
 * Fitur:
 * - OLD Article tab scroll system (data-section + #azTabsShell)
 * - NEW Article tab panel switcher (data-target + .az-tab-panel)
 * - Home tabs (About / Announcements)
 * - Mobile nav toggle
 * - changeActiveTab() legacy helper
 */

document.addEventListener("DOMContentLoaded", () => {

    // ================================================
    // 1. OLD ARTICLE PAGE – TAB SYSTEM (SCROLL)
    //    Dipakai jika ada #azTabsShell + .az-article-tab[data-section]
    // ================================================
    const scrollTabShell = document.getElementById("azTabsShell");
    const scrollTabs     = document.querySelectorAll(".az-article-tab[data-section]");

    if (scrollTabShell && scrollTabs.length > 0) {
        const headerOffset = 110; // tinggi header untuk offset scroll

        // A. Klik tab → scroll ke section
        scrollTabs.forEach(tab => {
            tab.addEventListener("click", function () {

                // aktifkan tab yang diklik
                scrollTabs.forEach(t => t.classList.remove("is-active"));
                this.classList.add("is-active");

                const targetId = this.dataset.section;
                const targetEl = document.getElementById(targetId);
                if (!targetEl) return;

                const top = targetEl.getBoundingClientRect().top + window.pageYOffset - headerOffset;

                window.scrollTo({
                    top,
                    behavior: "smooth"
                });
            });
        });

        // B. Sticky behavior tabs
        const observer = new IntersectionObserver(
            ([entry]) => {
                scrollTabShell.classList.toggle("is-sticky", entry.intersectionRatio < 1);
            },
            { threshold: [1] }
        );
        observer.observe(scrollTabShell);

        // C. Auto-highlight tab berdasarkan scroll
        const sections = {};

        scrollTabs.forEach(tab => {
            const id = tab.dataset.section;
            const sec = document.getElementById(id);
            if (sec) sections[id] = sec;
        });

        window.addEventListener("scroll", () => {
            const scroll = window.scrollY + headerOffset + 40;

            let activeId = null;

            for (const id in sections) {
                const secTop = sections[id].offsetTop;
                const secBottom = secTop + sections[id].offsetHeight;

                if (scroll >= secTop && scroll < secBottom) {
                    activeId = id;
                    break;
                }
            }

            if (activeId) {
                scrollTabs.forEach(t => {
                    t.classList.toggle("is-active", t.dataset.section === activeId);
                });
            }
        });
    }

    // ================================================
    // 2. NEW ARTICLE TAB – PANEL SWITCHER (ALA UNAIR)
    //    Dipakai kalau tab punya data-target dan ada .az-tab-panel
    // ================================================
    const panelTabs = document.querySelectorAll(".az-article-tab[data-target]");
    const panels    = document.querySelectorAll(".az-tab-panel");

    if (panelTabs.length > 0 && panels.length > 0) {
        panelTabs.forEach(tab => {
            tab.addEventListener("click", () => {
                const target = tab.dataset.target;

                // Active tab
                panelTabs.forEach(t => t.classList.remove("is-active"));
                tab.classList.add("is-active");

                // Show correct panel
                panels.forEach(panel => {
                    panel.classList.toggle("is-active", panel.id === target);
                });

                // Mobile auto-scroll ke atas card
                if (window.innerWidth < 992) {
                    const card = document.querySelector(".obj_article_details");
                    if (card) {
                        const offset = 110;
                        const y = card.getBoundingClientRect().top + window.pageYOffset - offset;
                        window.scrollTo({ top: y, behavior: "smooth" });
                    }
                }
            });
        });
    }

    // ================================================
    // 3. HOME TABS – ABOUT / ANNOUNCEMENTS
    // ================================================
    const homeTabs   = document.querySelectorAll(".az-home-tab");
    const homePanels = document.querySelectorAll(".az-home-tab-panel");

    if (homeTabs.length && homePanels.length) {
        homeTabs.forEach(tab => {
            tab.addEventListener("click", () => {
                const target = tab.dataset.target;

                homeTabs.forEach(t => t.classList.remove("is-active"));
                tab.classList.add("is-active");

                homePanels.forEach(panel => {
                    panel.classList.toggle("is-active", panel.id === target);
                });

                // Scroll sedikit ke section di mobile
                if (window.innerWidth < 992) {
                    const section = document.querySelector(".az-home-about-tabs");
                    if (section) {
                        const offset = 110;
                        const y = section.getBoundingClientRect().top + window.pageYOffset - offset;
                        window.scrollTo({ top: y, behavior: "smooth" });
                    }
                }
            });
        });
    }

    // ================================================
    // 4. MOBILE NAV TOGGLE (HEADER)
    // ================================================
    const navToggle = document.querySelector(".az-nav-toggle");
    const mainNav   = document.querySelector(".az-main-nav");

    if (navToggle && mainNav) {
        navToggle.addEventListener("click", () => {
            mainNav.classList.toggle("is-open");
        });
    }
});


/**
 * Legacy helper – kalau masih ada markup lama yang pakai tabs-id + tab-abstract dll.
 */
function changeActiveTab(event, tabId) {
    const tabsContainer = document.getElementById('tabs-id');
    if (!tabsContainer) return;

    const tabLinks = tabsContainer.querySelectorAll('ul li a, button.az-article-tab');
    const tabPanels = tabsContainer.querySelectorAll(
        '#tab-abstract, #tab-citation, #tab-author-details, #tab-download, #tab-references, #tab-license, #tab-overview'
    );

    tabLinks.forEach(link => {
        link.classList.remove('is-active');
    });
    tabPanels.forEach(panel => {
        panel.classList.add('hidden');
    });

    if (event && event.currentTarget) {
        event.currentTarget.classList.add('is-active');
    }

    const activePanel = document.getElementById(tabId);
    if (activePanel) {
        activePanel.classList.remove('hidden');
    }
}
