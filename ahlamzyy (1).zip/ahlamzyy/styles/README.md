ahlamzyy-base.css         → warna, font, variable global
ahlamzyy-header.css       → header, topbar, nav
ahlamzyy-components.css   → breadcrumbs, buttons, tags, badges, cards kecil
ahlamzyy-homepage.css     → layout homepage journal
ahlamzyy-issue.css        → layout issue (TOC)
ahlamzyy-article.css      → layout article view
ahlamzyy-journal.css      → layout halaman umum jurnal (About, Editorial, Submissions)
ahlamzyy-footer.css       → footer
